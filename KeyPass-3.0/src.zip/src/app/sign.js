/* const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
let PUBLIC = "-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA0cAtkr5cNrhq3PiFuCpL\n1y1hNwzm0Mf4GFXozKXDNIdlwZ8YNMinjZil/rtfOEaOsvMfRE+qhx51MfS0BEPe\ncmQZ1Ld/YHFfJpraFqDB2WyCCgAAW4kbiTW3eLpBNMoZtw1qhMl/wIkjCZNaSWRm\nYVUjsqLLJVfDZzfmMNv3DOOQ4EH4CODMYNuh76R0ELxCF2VhbFYTes4/P91MlMVE\nxYgs6nsnnf4spKUBZxrfdnMN7PeTm/Tp0tNsOTkYLj7YTE3ZRRwONVQ1i804lr31\nDwYk5gHc76CFedKc9pDvjK3ZJaS/TbmZRxcG3kCSk25ljODK9M2ndTmxendZbmCD\nJzvhb+W0o3pWz/uHLNgvAnftzqT/bG/TJ8mCr4pVojewLROILzSLK58/H1rsZmcf\nbZKY45EmU/RgMXVC4m1DrbI0lEnAeSjGQBFIFoGWoGs30WCkO1IrSMzqVQwdQs/3\nLr0lYiFMDx6+lRUtMVbKRx9FO6rGHPHlfwR8adZGAQUUsVX8k7H9Gij199i8Xxjq\nqZ1BMiIa2nliTOGSlMraz58q4YiSZ88LKPKhtcNbN2v8ydQBV4n9n/TazraOjUCw\n9Lp72CmdyUauet6U7iiqBnywEwAZkyQqGHSai3whluXU8877VfcTPIjCk1xjEUaa\nU0JYBz2f3l38YUpkNrTWHjMCAwEAAQ==\n-----END PUBLIC KEY-----\n"
console.log(PUBLIC)
PUBLIC = Buffer.from(PUBLIC)
const PUBLIC_KE = fs.readFileSync(path.join(__dirname, 'jwtRS256.key.pub'));
let token = jwt.sign({ user: "admin" }, PUBLIC, { algorithm: "HS256" })
let token2 = jwt.sign({ user: "admin" }, PUBLIC_KE, { algorithm: "HS256" })
console.log(token)
console.log(token2)
jwt.verify(token, PUBLIC_KE, (err, decoded) => {
    if (err) {
        console.log(err)
    } else {
        console.log(decoded)
    }
}); */

let a
let b = "aaa"
console.log(a || b)